/* ================================================================
   WORLD MONITOR — Big History Perspective JS
   Embedded dashboard section: overlay comparison, prediction corridor,
   civilization pulse chart. Designed to be called from dashboard.js
   after all other charts are rendered.
   ================================================================ */

(function () {
    'use strict';

    // Guard: only initialize once
    if (window.__bhInitialized) return;
    window.__bhInitialized = true;

    // Dark theme colors (consistent with dashboard.js)
    var COLORS = {
        bg: '#111a2c',
        text: '#8899b4',
        axis: '#1a2740',
        blue: '#38bdf8',
        cyan: '#22d3ee',
        green: '#22c55e',
        amber: '#f59e0b',
        orange: '#f97316',
        red: '#ef4444',
        purple: '#a855f7',
        white: '#e0e6f0',
    };

    // Chart instance tracking
    var _charts = {};
    var _loading = false;

    function disposeChart(key) {
        if (_charts[key]) {
            try { _charts[key].dispose(); } catch(e) {}
            delete _charts[key];
        }
    }

    function disposeAll() {
        Object.keys(_charts).forEach(disposeChart);
    }

    function darkTooltip() {
        return {
            backgroundColor: 'rgba(10, 16, 31, 0.95)',
            borderColor: COLORS.axis,
            textStyle: { color: '#e0e6f0', fontSize: 12 },
        };
    }

    // ═══════════════════════════════════════════════════════════
    // Overlay Comparison Chart
    // ═══════════════════════════════════════════════════════════

    function initOverlayChart(queryData, bestAnalog, indicatorInfo) {
        var dom = document.getElementById('chart-overlay');
        if (!dom) return;

        disposeChart('overlay');
        var chart = echarts.init(dom, 'dark');
        _charts.overlay = chart;

        if (!queryData || !queryData.history || queryData.history.length === 0) {
            chart.setOption({
                title: { text: '选择指标以查看曲线对比', left: 'center', top: 'center',
                    textStyle: { color: COLORS.text, fontSize: 13 } },
            });
            return;
        }

        var histDates = queryData.history.map(function (d) { return d.date ? d.date.slice(0, 10) : ''; });
        var histValues = queryData.history.map(function (d) { return d.value; });

        var qwSize = 6;
        var qwStartIdx = Math.max(0, histDates.length - qwSize);

        var series = [{
            name: indicatorInfo.name_cn + ' (完整历史)',
            type: 'line',
            data: histValues,
            smooth: true,
            symbol: 'circle',
            symbolSize: 3,
            lineStyle: { color: COLORS.cyan, width: 2 },
            itemStyle: { color: COLORS.cyan },
            areaStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: 'rgba(34, 211, 238, 0.15)' },
                    { offset: 1, color: 'rgba(34, 211, 238, 0.0)' },
                ]),
            },
            markArea: {
                silent: true,
                data: [[
                    { xAxis: histDates[qwStartIdx] },
                    { xAxis: histDates[histDates.length - 1] },
                ]],
                label: { show: true, position: 'insideTop', color: COLORS.cyan, fontSize: 10, formatter: '当前窗口' },
                itemStyle: { color: 'rgba(34, 211, 238, 0.06)', borderColor: COLORS.cyan, borderWidth: 1, borderType: 'dashed' },
            },
        }];

        // Best analog match
        if (bestAnalog && bestAnalog.match_values && bestAnalog.match_values.length > 0) {
            var analogVals = bestAnalog.match_values || [];
            var alignIdx = qwStartIdx;
            var alignedData = [];
            for (var i = 0; i < histDates.length; i++) {
                if (i >= alignIdx && (i - alignIdx) < analogVals.length) {
                    alignedData.push(analogVals[i - alignIdx]);
                } else {
                    alignedData.push(null);
                }
            }

            series.push({
                name: bestAnalog.indicator_name_cn + ' (' + (bestAnalog.match_dates ? bestAnalog.match_dates[0].slice(0,4) : '') + ')',
                type: 'line',
                data: alignedData,
                smooth: true,
                symbol: 'diamond',
                symbolSize: 5,
                lineStyle: { color: COLORS.amber, width: 2, type: 'dashed' },
                itemStyle: { color: COLORS.amber },
            });

            var titleEl = document.getElementById('overlay-title');
            if (titleEl) {
                titleEl.textContent = '📊 ' + indicatorInfo.name_cn + ' ↔ ' +
                    bestAnalog.indicator_name_cn + ' (相似度: ' +
                    Math.round(bestAnalog.similarity_score * 100) + '%)';
            }
        }

        chart.setOption({
            backgroundColor: 'transparent',
            grid: { left: 55, right: 25, top: 50, bottom: 35 },
            tooltip: {
                trigger: 'axis',
                ...darkTooltip(),
                formatter: function (params) {
                    var html = '<b>' + params[0].axisValue + '</b><br/>';
                    params.forEach(function (p) {
                        if (p.value !== null && p.value !== undefined) {
                            html += '<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:' +
                                p.color + ';margin-right:4px;"></span>' +
                                p.seriesName + ': <b>' + (typeof p.value === 'number' ? p.value.toFixed(2) : p.value) +
                                '</b><br/>';
                        }
                    });
                    return html;
                },
            },
            xAxis: {
                type: 'category',
                data: histDates,
                axisLine: { lineStyle: { color: COLORS.axis } },
                axisTick: { show: false },
                axisLabel: { color: COLORS.text, fontSize: 10,
                    formatter: function (v) { return v.length > 7 ? v.slice(0, 7) : v; } },
            },
            yAxis: {
                type: 'value',
                name: indicatorInfo.unit || '',
                nameTextStyle: { color: COLORS.text, fontSize: 10 },
                splitLine: { lineStyle: { color: COLORS.axis, type: 'dashed' } },
                axisLabel: { color: COLORS.text, fontSize: 10 },
            },
            legend: { bottom: 0, textStyle: { color: COLORS.text, fontSize: 10 },
                data: series.map(function (s) { return s.name; }) },
            series: series,
        });
    }

    // ═══════════════════════════════════════════════════════════
    // Prediction Corridor Chart
    // ═══════════════════════════════════════════════════════════

    function initPredictionChart(predictionData) {
        var dom = document.getElementById('chart-prediction');
        if (!dom) return;

        disposeChart('prediction');
        var chart = echarts.init(dom, 'dark');
        _charts.prediction = chart;

        if (!predictionData || !predictionData.history || predictionData.history.length === 0) {
            chart.setOption({
                title: { text: '选择指标以生成预测', left: 'center', top: 'center',
                    textStyle: { color: COLORS.text, fontSize: 13 } },
            });
            return;
        }

        var histDates = predictionData.history.map(function (d) { return d.date ? d.date.slice(0, 10) : ''; });
        var histValues = predictionData.history.map(function (d) { return d.value; });

        var centralDates = (predictionData.central || []).map(function (d) { return d.date ? d.date.slice(0, 10) : ''; });
        var centralVals = (predictionData.central || []).map(function (d) { return d.value; });
        var optimVals = (predictionData.optimistic || []).map(function (d) { return d.value; });
        var pessimVals = (predictionData.pessimistic || []).map(function (d) { return d.value; });

        var allDates = histDates.concat(centralDates);

        // Build aligned arrays
        var padLen = centralDates.length;
        var histAligned = histValues.concat(new Array(padLen));
        var centralAligned = [];
        var optimAligned = [];
        var pessimAligned = [];
        for (var i = 0; i < histDates.length; i++) {
            centralAligned.push(null);
            optimAligned.push(null);
            pessimAligned.push(null);
        }
        centralAligned = centralAligned.concat(centralVals);
        optimAligned = optimAligned.concat(optimVals);
        pessimAligned = pessimAligned.concat(pessimVals);

        // Continuity: connect last history point to predictions
        if (histValues.length > 0 && centralDates.length > 0) {
            centralAligned[histDates.length - 1] = histValues[histValues.length - 1];
            optimAligned[histDates.length - 1] = histValues[histValues.length - 1];
            pessimAligned[histDates.length - 1] = histValues[histValues.length - 1];
        }

        var series = [
            {
                name: '历史数据', type: 'line', data: histAligned, smooth: true,
                symbol: 'circle', symbolSize: 3,
                lineStyle: { color: COLORS.cyan, width: 2.5 },
                itemStyle: { color: COLORS.cyan }, z: 3,
            },
            {
                name: '乐观预测', type: 'line', data: optimAligned, smooth: true,
                symbol: 'none',
                lineStyle: { color: COLORS.green, width: 1, type: 'dashed', opacity: 0.5 },
                areaStyle: { color: 'rgba(34, 197, 94, 0.06)' },
                stack: 'band', z: 1,
            },
            {
                name: '中枢预测', type: 'line', data: centralAligned, smooth: true,
                symbol: 'diamond', symbolSize: 5,
                lineStyle: { color: COLORS.white, width: 2, type: 'dashed' },
                itemStyle: { color: COLORS.white }, z: 2,
            },
            {
                name: '悲观预测', type: 'line', data: pessimAligned, smooth: true,
                symbol: 'none',
                lineStyle: { color: COLORS.red, width: 1, type: 'dashed', opacity: 0.5 },
                areaStyle: { color: 'transparent' },
                stack: 'band', z: 0,
            },
        ];

        // Confidence badge
        var confBadge = document.getElementById('confidence-badge');
        if (confBadge && predictionData.confidence != null) {
            var conf = predictionData.confidence;
            confBadge.style.display = 'inline-flex';
            confBadge.textContent = '置信度: ' + Math.round(conf * 100) + '%';
            confBadge.className = 'bh-confidence ' + (conf >= 0.7 ? 'high' : conf >= 0.4 ? 'medium' : 'low');
        }

        chart.setOption({
            backgroundColor: 'transparent',
            grid: { left: 55, right: 25, top: 20, bottom: 35 },
            tooltip: {
                trigger: 'axis',
                ...darkTooltip(),
                formatter: function (params) {
                    var html = '<b>' + params[0].axisValue + '</b><br/>';
                    params.forEach(function (p) {
                        if (p.value !== null && p.value !== undefined) {
                            html += '<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:' +
                                p.color + ';margin-right:4px;"></span>' +
                                p.seriesName + ': <b>' + p.value.toFixed(2) +
                                ' ' + (predictionData.unit || '') + '</b><br/>';
                        }
                    });
                    return html;
                },
            },
            xAxis: {
                type: 'category', data: allDates,
                axisLine: { lineStyle: { color: COLORS.axis } },
                axisTick: { show: false },
                axisLabel: { color: COLORS.text, fontSize: 10,
                    formatter: function (v) { return v.length > 7 ? v.slice(0, 7) : v; } },
            },
            yAxis: {
                type: 'value', name: predictionData.unit || '',
                nameTextStyle: { color: COLORS.text, fontSize: 10 },
                splitLine: { lineStyle: { color: COLORS.axis, type: 'dashed' } },
                axisLabel: { color: COLORS.text, fontSize: 10 },
            },
            legend: { bottom: 0, textStyle: { color: COLORS.text, fontSize: 10 },
                data: ['历史数据', '中枢预测', '乐观预测', '悲观预测'] },
            series: series,
        });
    }

    // ═══════════════════════════════════════════════════════════
    // Civilization Pulse Chart
    // ═══════════════════════════════════════════════════════════

    function initPulseChart() {
        var dom = document.getElementById('chart-pulse');
        var pulseData = window.__pulseData;
        if (!dom || !pulseData || !pulseData.dates || pulseData.dates.length === 0) return;

        // Don't recreate if already initialized
        if (_charts.pulse) return;

        var chart = echarts.init(dom, 'dark');
        _charts.pulse = chart;

        chart.setOption({
            backgroundColor: 'transparent',
            grid: { left: 60, right: 30, top: 30, bottom: 35 },
            tooltip: {
                trigger: 'axis',
                ...darkTooltip(),
                formatter: function (params) {
                    var p = params[0];
                    return '<b>' + p.axisValue + '</b><br/>文明脉搏指数: <b>' +
                        (p.value !== null ? p.value.toFixed(4) : '--') + '</b>';
                },
            },
            xAxis: {
                type: 'category', data: pulseData.dates,
                axisLine: { lineStyle: { color: COLORS.axis } },
                axisTick: { show: false },
                axisLabel: { color: COLORS.text, fontSize: 10,
                    interval: Math.max(1, Math.floor(pulseData.dates.length / 12)) },
            },
            yAxis: {
                type: 'value', name: '归一化指数', min: 0, max: 1,
                nameTextStyle: { color: COLORS.text, fontSize: 10 },
                splitLine: { lineStyle: { color: COLORS.axis, type: 'dashed' } },
                axisLabel: { color: COLORS.text, fontSize: 10,
                    formatter: function (v) { return v.toFixed(1); } },
            },
            series: [{
                name: '文明脉搏', type: 'line', data: pulseData.values, smooth: true,
                symbol: 'circle', symbolSize: 3,
                lineStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0.5, 0, [
                        { offset: 0, color: COLORS.purple },
                        { offset: 0.5, color: COLORS.blue },
                        { offset: 1, color: COLORS.cyan },
                    ]),
                    width: 2.5,
                },
                itemStyle: { color: COLORS.purple },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        { offset: 0, color: 'rgba(168, 85, 247, 0.25)' },
                        { offset: 1, color: 'rgba(56, 189, 248, 0.02)' },
                    ]),
                },
                markLine: {
                    silent: true,
                    data: [{ yAxis: 0.5, label: { formatter: '中位线', fontSize: 10 },
                        lineStyle: { color: COLORS.text, type: 'dotted', opacity: 0.4 } }],
                },
            }],
        });
    }

    // ═══════════════════════════════════════════════════════════
    // Analog List Renderer
    // ═══════════════════════════════════════════════════════════

    function renderAnalogList(analogs, indicatorInfo) {
        var listEl = document.getElementById('analogs-list');
        if (!listEl) return;

        if (!analogs || analogs.length === 0) {
            listEl.innerHTML = '<div class="bh-empty"><div class="bh-empty-icon">📭</div>暂无足够历史数据<br/><small>需要至少8个历史数据点才能进行模式匹配</small></div>';
            return;
        }

        var html = '';
        analogs.forEach(function (analog, idx) {
            var score = Math.round(analog.similarity_score * 100);
            var isSelf = analog.is_self_match;
            var isCross = analog.is_cross_category;
            var datesStr = analog.match_dates ? (analog.match_dates[0].slice(0,4) + '~' + analog.match_dates[analog.match_dates.length-1].slice(0,4)) : '';

            html += '<div class="bh-analog-card" onclick="selectAnalog(' + idx + ')" id="analog-card-' + idx + '">';
            html += '<div class="bh-analog-rank">#' + (idx + 1) + ' 匹配</div>';
            html += '<div class="bh-analog-name">' + analog.indicator_name_cn + '</div>';
            html += '<div class="bh-analog-period">' + datesStr + '</div>';
            html += '<div class="bh-analog-meta">';
            if (isSelf) html += '<span class="bh-analog-badge self">自身</span>';
            else if (isCross) html += '<span class="bh-analog-badge cross">跨领域</span>';
            html += '<span>' + analog.category + '</span></div>';
            html += '<div class="bh-analog-score-bar"><div class="bh-analog-score-fill" style="width:' + score + '%;"></div></div>';
            html += '<div class="bh-analog-score-label">相似度: ' + score + '%</div>';
            html += '</div>';
        });

        listEl.innerHTML = html;
    }

    function selectAnalog(idx) {
        // Only update UI highlight — DON'T trigger API fetch (that causes infinite loop)
        document.querySelectorAll('.bh-analog-card').forEach(function (c) { c.classList.remove('selected'); });
        var card = document.getElementById('analog-card-' + idx);
        if (card) card.classList.add('selected');
        window.__selectedAnalogIdx = idx;

        // Re-render overlay chart with the selected analog from already-fetched data
        var analogs = window.__currentAnalogs || [];
        var predictData = window.__currentPredictions;
        if (predictData && analogs.length > idx) {
            var indicators = window.__bhIndicators || [];
            var indicatorInfo = {};
            var selectEl = document.getElementById('indicator-select');
            var indicatorId = selectEl ? selectEl.value : null;
            for (var i = 0; i < indicators.length; i++) {
                if (indicators[i].id == indicatorId) { indicatorInfo = indicators[i]; break; }
            }
            initOverlayChart(predictData, analogs[idx], indicatorInfo);
        }
    }

    // ═══════════════════════════════════════════════════════════
    // Data Loading
    // ═══════════════════════════════════════════════════════════

    function loadDataAndRender() {
        if (_loading) return;  // prevent concurrent loads
        _loading = true;

        var selectEl = document.getElementById('indicator-select');
        var horizonEl = document.getElementById('horizon-select');
        if (!selectEl) { _loading = false; return; }

        var indicatorId = selectEl.value;
        var horizon = horizonEl ? parseInt(horizonEl.value) : 5;

        // Find indicator info
        var indicators = window.__bhIndicators || [];
        var indicatorInfo = {};
        for (var i = 0; i < indicators.length; i++) {
            if (indicators[i].id == indicatorId) {
                indicatorInfo = indicators[i];
                break;
            }
        }

        // Show subtle loading state in the list only
        var listEl = document.getElementById('analogs-list');
        if (listEl && !document.querySelector('.bh-analog-card')) {
            listEl.innerHTML = '<div class="bh-loading">⏳ 计算DTW模式匹配...</div>';
        }

        var analogUrl = '/api/big-history/analogs?indicator_id=' + indicatorId + '&top_k=5&window_size=6';
        var predictUrl = '/api/big-history/predictions?indicator_id=' + indicatorId + '&horizon_years=' + horizon;

        Promise.all([
            fetch(analogUrl).then(function (r) { return r.json(); }),
            fetch(predictUrl).then(function (r) { return r.json(); }),
        ]).then(function (results) {
            var analogData = results[0];
            var predictData = results[1];
            var analogs = analogData.analogs || [];

            window.__currentAnalogs = analogs;
            window.__currentPredictions = predictData;

            // Pick best or selected analog
            var selIdx = (window.__selectedAnalogIdx != null) ? window.__selectedAnalogIdx : 0;
            var bestAnalog = (analogs.length > selIdx) ? analogs[selIdx] : null;

            // Render
            renderAnalogList(analogs, indicatorInfo);
            initOverlayChart(predictData, bestAnalog, indicatorInfo);
            initPredictionChart(predictData);

            if (bestAnalog && analogs.length > 0) {
                setTimeout(function () { selectAnalog(selIdx); }, 50);
            }

            _loading = false;
        }).catch(function (err) {
            console.error('Big History fetch error:', err);
            if (listEl) listEl.innerHTML = '<div class="bh-empty"><div class="bh-empty-icon">⚠</div>数据加载失败</div>';
            _loading = false;
        });
    }

    // ═══════════════════════════════════════════════════════════
    // Public API — called from dashboard.js after chart init
    // ═══════════════════════════════════════════════════════════

    window.initBigHistorySection = function () {
        // Render civilization pulse (static server data, no API call needed)
        initPulseChart();
        // Auto-load the default indicator
        if (window.__defaultIndicatorId) {
            loadDataAndRender();
        }
    };

    // Globals for onclick handlers
    window.onIndicatorChange = function () {
        window.__selectedAnalogIdx = 0;
        loadDataAndRender();
    };
    window.selectAnalog = selectAnalog;

    // Handle window resize for big history charts only
    window.addEventListener('resize', function () {
        Object.keys(_charts).forEach(function (key) {
            try { _charts[key].resize(); } catch(e) {}
        });
    });

})();
