/* ================================================================
   WORLD MONITOR — Dashboard Charts (ECharts)
   ================================================================ */

(function () {
    'use strict';

    // Dark theme colors matching CSS variables
    const COLORS = {
        bg: '#111a2c',
        text: '#8899b4',
        axis: '#1a2740',
        blue: '#38bdf8',
        cyan: '#22d3ee',
        green: '#22c55e',
        amber: '#f59e0b',
        orange: '#f97316',
        red: '#ef4444',
        purple: '#a855f7',
    };

    /**
     * Initialize a single line chart in the given DOM element.
     */
    function initLineChart(domId, title, unit, dataPoints) {
        const dom = document.getElementById(domId);
        if (!dom || !dataPoints || dataPoints.length === 0) return;

        const chart = echarts.init(dom, 'dark');

        const dates = dataPoints.map(d => d.date ? d.date.slice(0, 10) : '');
        const values = dataPoints.map(d => d.value);

        const option = {
            backgroundColor: 'transparent',
            grid: {
                left: 50,
                right: 20,
                top: 20,
                bottom: 30,
            },
            tooltip: {
                trigger: 'axis',
                backgroundColor: 'rgba(10, 16, 31, 0.95)',
                borderColor: COLORS.axis,
                textStyle: { color: '#e0e6f0', fontSize: 12 },
                formatter: function (params) {
                    const p = params[0];
                    return `${p.axisValue}<br/>${title}: <b>${p.value} ${unit}</b>`;
                },
            },
            xAxis: {
                type: 'category',
                data: dates,
                axisLine: { lineStyle: { color: COLORS.axis } },
                axisTick: { show: false },
                axisLabel: {
                    color: COLORS.text,
                    fontSize: 10,
                    formatter: function (v) { return v.length > 7 ? v.slice(0, 7) : v; },
                },
            },
            yAxis: {
                type: 'value',
                name: unit,
                nameTextStyle: { color: COLORS.text, fontSize: 10 },
                splitLine: { lineStyle: { color: COLORS.axis, type: 'dashed' } },
                axisLabel: { color: COLORS.text, fontSize: 10 },
            },
            series: [{
                data: values,
                type: 'line',
                smooth: true,
                symbol: 'circle',
                symbolSize: 4,
                lineStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                        { offset: 0, color: COLORS.blue },
                        { offset: 1, color: COLORS.cyan },
                    ]),
                    width: 2,
                },
                itemStyle: {
                    color: COLORS.cyan,
                },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        { offset: 0, color: 'rgba(56, 189, 248, 0.2)' },
                        { offset: 1, color: 'rgba(56, 189, 248, 0.01)' },
                    ]),
                },
            }],
        };

        chart.setOption(option);

        // Responsive resize
        window.addEventListener('resize', () => chart.resize());
    }

    /**
     * Initialize the world conflict map.
     * Uses ECharts geo component with registered 'world' map.
     * Map GeoJSON loaded from /static/data/echarts-world.js
     */
    function initWorldMap() {
        var dom = document.getElementById('world-map-container');
        if (!dom) return;

        var intensityColors = {
            5: COLORS.red,
            4: COLORS.orange,
            3: COLORS.amber,
            2: COLORS.blue,
            1: COLORS.text,
        };

        var hotspots = window.__conflictHotspots || [];

        var lowData = [];
        var highData = [];
        hotspots.forEach(function (h) {
            var pt = {
                name: h.name,
                value: [h.lng, h.lat, h.intensity],
                detail: h.detail || '',
                intensity: h.intensity,
            };
            if (h.intensity >= 4) {
                highData.push(pt);
            } else {
                lowData.push(pt);
            }
        });

        var chart = echarts.init(dom, 'dark');

        var option = {
            backgroundColor: 'transparent',
            tooltip: {
                trigger: 'item',
                backgroundColor: 'rgba(10, 16, 31, 0.95)',
                borderColor: COLORS.axis,
                textStyle: { color: '#e0e6f0', fontSize: 12 },
                formatter: function (p) {
                    var levels = ['','','关注级','重大级','战略级','文明级'];
                    var lvl = p.data.intensity || 0;
                    return '<b>' + p.name + '</b><br/>' +
                           '强度: <span style="color:' + (intensityColors[lvl]||COLORS.text) + '">L' + lvl + ' ' + (levels[lvl]||'') + '</span><br/>' +
                           (p.data.detail || '');
                },
            },
            geo: {
                map: 'world',
                roam: true,
                zoom: 1.15,
                center: [15, 20],
                aspectScale: 0.75,
                itemStyle: {
                    areaColor: '#0b1320',
                    borderColor: '#1e3550',
                    borderWidth: 0.6,
                },
                emphasis: {
                    itemStyle: {
                        areaColor: '#152238',
                    },
                    label: { show: false },
                },
            },
            series: [
                // Ripple effect for L4-L5 hotspots
                {
                    type: 'effectScatter',
                    coordinateSystem: 'geo',
                    data: highData,
                    symbolSize: function (val) { return val[2] * 7; },
                    showEffectOn: 'render',
                    rippleEffect: {
                        brushType: 'stroke',
                        scale: 3.5,
                        period: 4,
                        color: COLORS.red,
                    },
                    itemStyle: {
                        color: function (p) { return intensityColors[p.data.intensity] || COLORS.red; },
                        shadowBlur: 10,
                        shadowColor: COLORS.red,
                    },
                    label: {
                        show: true,
                        position: 'right',
                        formatter: '{b}',
                        color: '#f0f0f0',
                        fontSize: 10,
                        distance: 8,
                    },
                    zlevel: 2,
                },
                // Static dots for L2-L3
                {
                    type: 'scatter',
                    coordinateSystem: 'geo',
                    data: lowData,
                    symbolSize: function (val) { return val[2] * 5 + 6; },
                    itemStyle: {
                        color: function (p) { return intensityColors[p.data.intensity] || COLORS.text; },
                        borderColor: 'rgba(0,0,0,0.4)',
                        borderWidth: 1.5,
                    },
                    label: {
                        show: true,
                        position: 'right',
                        formatter: '{b}',
                        color: COLORS.text,
                        fontSize: 9,
                        distance: 6,
                    },
                    emphasis: {
                        scale: 2,
                        label: { fontSize: 12, fontWeight: 'bold' },
                    },
                    zlevel: 2,
                },
            ],
        };

        chart.setOption(option);
        window.addEventListener('resize', function () { chart.resize(); });
        dom._echartInstance = chart;
    }

    /**
     * Render all chart panels from server-provided data.
     */
    function renderAllCharts() {
        const chartData = window.__chartData;
        if (chartData && Array.isArray(chartData)) {
            chartData.forEach(function (ci, index) {
                const domId = 'chart-' + index;
                initLineChart(domId, ci.indicator.name_cn, ci.indicator.unit, ci.history);
            });
        }
        // Initialize world map
        initWorldMap();
        // Initialize Big History section (if present on page) — once only
        if (window.initBigHistorySection && !window.__bhStarted && document.getElementById('chart-pulse')) {
            window.__bhStarted = true;
            // Use rAF for smooth rendering after layout settles
            requestAnimationFrame(function () {
                requestAnimationFrame(function () {
                    window.initBigHistorySection();
                });
            });
        }
    }

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', renderAllCharts);
    } else {
        renderAllCharts();
    }
})();
