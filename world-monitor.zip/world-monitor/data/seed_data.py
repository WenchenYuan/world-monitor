"""
Seed data for World Monitor — realistic indicator values circa mid-2026.
Sources noted inline. Run once to populate a fresh database.
"""

from datetime import datetime, timezone

INDICATORS = [
    # ===== ECONOMY (经济) =====
    {
        "category": "economy", "name": "US Fed Funds Rate", "name_cn": "美国联邦基金利率",
        "unit": "%", "value": 5.375, "previous_value": 5.50,
        "trend": "down", "importance": 5,
        "description": "美联储基准利率，影响全球资产定价与资本流动。2024年9月开始降息周期，2026年继续缓慢下调。",
        "source_name": "Federal Reserve (FRED)", "source_url": "https://fred.stlouisfed.org/series/DFEDTARU",
        "update_frequency": "daily",
    },
    {
        "category": "economy", "name": "US CPI YoY", "name_cn": "美国CPI同比",
        "unit": "%", "value": 3.1, "previous_value": 3.3,
        "trend": "down", "importance": 5,
        "description": "美国消费者价格指数年增率。核心通胀指标，直接影响美联储政策路径。",
        "source_name": "Bureau of Labor Statistics", "source_url": "https://www.bls.gov/cpi/",
        "update_frequency": "monthly",
    },
    {
        "category": "economy", "name": "US Nonfarm Payrolls", "name_cn": "美国非农就业人数",
        "unit": "M", "value": 159.5, "previous_value": 159.2,
        "trend": "up", "importance": 4,
        "description": "美国非农业部门就业总人数。衡量劳动力市场健康度的核心指标。",
        "source_name": "Bureau of Labor Statistics", "source_url": "https://www.bls.gov/ces/",
        "update_frequency": "monthly",
    },
    {
        "category": "economy", "name": "Global GDP Growth", "name_cn": "全球GDP增速",
        "unit": "%", "value": 3.1, "previous_value": 3.2,
        "trend": "down", "importance": 4,
        "description": "IMF估算的全球实际GDP年增长率，反映世界经济总体活力。",
        "source_name": "IMF World Economic Outlook", "source_url": "https://www.imf.org/en/Publications/WEO",
        "update_frequency": "quarterly",
    },
    {
        "category": "economy", "name": "WTI Crude Oil", "name_cn": "WTI原油价格",
        "unit": "USD/bbl", "value": 78.5, "previous_value": 82.0,
        "trend": "down", "importance": 4,
        "description": "西德克萨斯中质原油期货价格。全球能源定价基准之一。",
        "source_name": "CME / Yahoo Finance", "source_url": "https://finance.yahoo.com/quote/CL=F",
        "update_frequency": "daily",
    },
    {
        "category": "economy", "name": "Gold Price", "name_cn": "黄金价格",
        "unit": "USD/oz", "value": 2420.0, "previous_value": 2350.0,
        "trend": "up", "importance": 3,
        "description": "国际黄金现货价格。终极避险资产，反映全球不确定性。",
        "source_name": "LBMA / Yahoo Finance", "source_url": "https://finance.yahoo.com/quote/GC=F",
        "update_frequency": "daily",
    },
    {
        "category": "economy", "name": "S&P 500 Index", "name_cn": "标普500指数",
        "unit": "pts", "value": 5850.0, "previous_value": 5700.0,
        "trend": "up", "importance": 3,
        "description": "美国500家大型上市公司市值加权指数，全球股市风向标。",
        "source_name": "S&P Global / Yahoo Finance", "source_url": "https://finance.yahoo.com/quote=^GSPC",
        "update_frequency": "daily",
    },
    {
        "category": "economy", "name": "CSI 300 Index", "name_cn": "沪深300指数",
        "unit": "pts", "value": 4050.0, "previous_value": 3980.0,
        "trend": "up", "importance": 3,
        "description": "中国A股市场最具代表性的300只股票指数。",
        "source_name": "中证指数 / Yahoo Finance", "source_url": "https://finance.yahoo.com/quote=000300.SS",
        "update_frequency": "daily",
    },
    {
        "category": "economy", "name": "US 10Y Treasury Yield", "name_cn": "美国10年期国债收益率",
        "unit": "%", "value": 4.15, "previous_value": 4.28,
        "trend": "down", "importance": 4,
        "description": "全球无风险利率的基准，影响从房贷到新兴市场债务的一切。",
        "source_name": "U.S. Treasury / FRED", "source_url": "https://fred.stlouisfed.org/series/DGS10",
        "update_frequency": "daily",
    },

    # ===== POLITICS (政治) =====
    {
        "category": "politics", "name": "Active Armed Conflicts", "name_cn": "全球活跃武装冲突数量",
        "unit": "conflicts", "value": 56, "previous_value": 54,
        "trend": "up", "importance": 5,
        "description": "UCDP/PRIO定义的活跃国家间与内战冲突总数。超过50表明世界处于高冲突水平。",
        "source_name": "UCDP Uppsala Conflict Data Program", "source_url": "https://ucdp.uu.se/",
        "update_frequency": "yearly",
    },
    {
        "category": "politics", "name": "UNSC Resolutions", "name_cn": "联合国安理会决议数(年度)",
        "unit": "resolutions", "value": 62, "previous_value": 58,
        "trend": "up", "importance": 2,
        "description": "联合国安理会年度通过的决议数量，反映国际社会对危机回应的频率。",
        "source_name": "UN Security Council", "source_url": "https://www.un.org/securitycouncil/content/resolutions",
        "update_frequency": "yearly",
    },
    {
        "category": "politics", "name": "Democracy Index Avg", "name_cn": "全球民主指数均值",
        "unit": "/10", "value": 5.45, "previous_value": 5.50,
        "trend": "down", "importance": 3,
        "description": "EIU全球民主指数各国均值。持续下降表明全球民主退化趋势。",
        "source_name": "EIU Democracy Index", "source_url": "https://www.eiu.com/n/campaigns/democracy-index/",
        "update_frequency": "yearly",
    },
    {
        "category": "politics", "name": "Trade Restrictions", "name_cn": "全球新增贸易限制措施(年)",
        "unit": "measures", "value": 3400, "previous_value": 3100,
        "trend": "up", "importance": 3,
        "description": "各国年度新增的贸易限制措施总数，衡量全球化倒退程度。",
        "source_name": "WTO Trade Monitoring", "source_url": "https://www.wto.org/english/tratop_e/tpr_e/trade_monitoring_e.htm",
        "update_frequency": "yearly",
    },

    # ===== MILITARY (军事) =====
    {
        "category": "military", "name": "Global Military Expenditure", "name_cn": "全球军费开支",
        "unit": "USD T", "value": 2.44, "previous_value": 2.38,
        "trend": "up", "importance": 4,
        "description": "SIPRI统计的全球军事支出总和（万亿美元），连续第9年增长。",
        "source_name": "SIPRI", "source_url": "https://www.sipri.org/databases/milex",
        "update_frequency": "yearly",
    },
    {
        "category": "military", "name": "Global Nuclear Warheads", "name_cn": "全球核弹头总数(估计)",
        "unit": "warheads", "value": 12500, "previous_value": 12512,
        "trend": "stable", "importance": 5,
        "description": "全球核武器弹头估计总数。虽数量下降但现代化升级在加速。",
        "source_name": "FAS / SIPRI", "source_url": "https://fas.org/issues/nuclear-weapons/status-world-nuclear-forces/",
        "update_frequency": "yearly",
    },
    {
        "category": "military", "name": "Conflict Fatalities", "name_cn": "全球冲突死亡人数(年)",
        "unit": "persons", "value": 185000, "previous_value": 170000,
        "trend": "up", "importance": 4,
        "description": "UCDP统计的国家冲突年度直接死亡人数。",
        "source_name": "UCDP", "source_url": "https://ucdp.uu.se/",
        "update_frequency": "yearly",
    },

    # ===== TECHNOLOGY (技术) =====
    {
        "category": "technology", "name": "Global Space Launches", "name_cn": "全球航天发射次数(年)",
        "unit": "launches", "value": 270, "previous_value": 245,
        "trend": "up", "importance": 3,
        "description": "全球年度轨道发射总数。SpaceX占比约一半，中国约80次。",
        "source_name": "Space Launch Report / Wikipedia", "source_url": "https://en.wikipedia.org/wiki/List_of_spaceflight_launches",
        "update_frequency": "yearly",
    },
    {
        "category": "technology", "name": "Semiconductor Market", "name_cn": "全球半导体市场规模",
        "unit": "USD B", "value": 650, "previous_value": 610,
        "trend": "up", "importance": 4,
        "description": "全球半导体年销售额。AI芯片需求推动持续增长，地缘政治重塑供应链。",
        "source_name": "SIA / WSTS", "source_url": "https://www.semiconductors.org/",
        "update_frequency": "quarterly",
    },
    {
        "category": "technology", "name": "Largest AI Training Compute", "name_cn": "最大AI模型训练算力",
        "unit": "petaFLOP", "value": 250000000, "previous_value": 100000000,
        "trend": "up", "importance": 5,
        "description": "公开已知最大AI模型训练所用计算量。指数级增长趋势仍在持续。",
        "source_name": "Epoch AI", "source_url": "https://epochai.org/data/notable-ai-models",
        "update_frequency": "quarterly",
    },
    {
        "category": "technology", "name": "Renewable Energy Capacity", "name_cn": "全球可再生能源装机容量",
        "unit": "GW", "value": 4500, "previous_value": 3900,
        "trend": "up", "importance": 3,
        "description": "全球风能、太阳能等可再生能源发电装机总量。",
        "source_name": "IRENA", "source_url": "https://www.irena.org/Data",
        "update_frequency": "yearly",
    },

    # ===== LIVELIHOOD (民生) =====
    {
        "category": "livelihood", "name": "Atmospheric CO2", "name_cn": "大气CO2浓度",
        "unit": "ppm", "value": 426.5, "previous_value": 424.0,
        "trend": "up", "importance": 5,
        "description": "莫纳罗亚观测站测量的大气二氧化碳浓度（年均值），持续创历史新高。",
        "source_name": "NOAA Global Monitoring Lab", "source_url": "https://gml.noaa.gov/ccgg/trends/",
        "update_frequency": "monthly",
    },
    {
        "category": "livelihood", "name": "Global Temperature Anomaly", "name_cn": "全球平均温度距平",
        "unit": "°C", "value": 1.28, "previous_value": 1.25,
        "trend": "up", "importance": 5,
        "description": "相对于1850-1900年工业化前基准的全球地表平均温度升幅。",
        "source_name": "NASA GISS / Copernicus", "source_url": "https://data.giss.nasa.gov/gistemp/",
        "update_frequency": "monthly",
    },
    {
        "category": "livelihood", "name": "Extreme Poverty", "name_cn": "极端贫困人口",
        "unit": "M persons", "value": 620, "previous_value": 640,
        "trend": "down", "importance": 4,
        "description": "每日生活费低于2.15美元（2017 PPP）的全球人口估计。",
        "source_name": "World Bank", "source_url": "https://pip.worldbank.org/",
        "update_frequency": "yearly",
    },
    {
        "category": "livelihood", "name": "Global Food Price Index", "name_cn": "全球粮食价格指数",
        "unit": "pts", "value": 122.5, "previous_value": 118.0,
        "trend": "up", "importance": 4,
        "description": "FAO粮食价格指数，衡量一篮子粮食商品的国际价格变动。",
        "source_name": "FAO", "source_url": "https://www.fao.org/worldfoodsituation/foodpricesindex/en/",
        "update_frequency": "monthly",
    },
    {
        "category": "livelihood", "name": "Global Refugees", "name_cn": "全球难民与流离失所者",
        "unit": "M persons", "value": 120, "previous_value": 114,
        "trend": "up", "importance": 4,
        "description": "UNHCR统计的全球被迫流离失所人口总数（含难民、境内流离失所者、庇护寻求者）。",
        "source_name": "UNHCR", "source_url": "https://www.unhcr.org/refugee-statistics/",
        "update_frequency": "yearly",
    },
    {
        "category": "livelihood", "name": "Global Population", "name_cn": "全球人口",
        "unit": "B persons", "value": 8.12, "previous_value": 8.05,
        "trend": "up", "importance": 3,
        "description": "联合国估算的全球总人口。增速持续放缓，部分地区开始负增长。",
        "source_name": "UN Population Division", "source_url": "https://population.un.org/wpp/",
        "update_frequency": "yearly",
    },

    # ===== COMPOSITE (综合) =====
    {
        "category": "composite", "name": "Human Development Index", "name_cn": "人类发展指数(全球均值)",
        "unit": "/1.0", "value": 0.739, "previous_value": 0.737,
        "trend": "up", "importance": 3,
        "description": "UNDP综合衡量全球健康、教育、收入的人类发展水平。2023年后恢复缓慢增长。",
        "source_name": "UNDP", "source_url": "https://hdr.undp.org/data-center",
        "update_frequency": "yearly",
    },
    {
        "category": "composite", "name": "Global Peace Index", "name_cn": "全球和平指数(均值)",
        "unit": "/5.0", "value": 2.38, "previous_value": 2.35,
        "trend": "up", "importance": 3,
        "description": "IEP全球和平指数各国平均分（越低越好，<2=和平，>3=不和平）。上升表明世界更不和平。",
        "source_name": "Institute for Economics & Peace", "source_url": "https://www.visionofhumanity.org/",
        "update_frequency": "yearly",
    },
]

# High-energy signal events — importance ≥ 3
SIGNAL_EVENTS = [
    {
        "category": "politics", "title": "Ukraine Peace Negotiations Enter Critical Phase",
        "title_cn": "乌克兰和平谈判进入关键阶段",
        "description": "2026年春季多方斡旋下俄乌停火框架初步形成，但领土与安全保障条款仍存巨大分歧。结果将重塑欧洲安全架构。",
        "importance": 5,
        "source_name": "Reuters / UN",
    },
    {
        "category": "technology", "title": "GPT-5 Class Model Released — Broad AGI Capabilities Demonstrated",
        "title_cn": "GPT-5级模型发布——展示广泛AGI能力",
        "description": "最新大模型在数学推理、代码生成、科学发现等多项基准上接近人类专家水平，引发全球AI治理紧急讨论。",
        "importance": 5,
        "source_name": "AI Safety Institutes",
    },
    {
        "category": "economy", "title": "Global Debt Exceeds 330% of GDP — IMF Issues Warning",
        "title_cn": "全球债务超GDP 330%——IMF发出警告",
        "description": "IMF最新财政监测报告指出全球公共与私人债务总额达到GDP的330%，创历史新高，多国财政空间急剧收窄。",
        "importance": 4,
        "source_name": "IMF Fiscal Monitor",
    },
    {
        "category": "livelihood", "title": "Multi-Year Drought in Amazon Basin Intensifies",
        "title_cn": "亚马逊流域多年干旱加剧",
        "description": "亚马逊雨林连续第三年遭遇极端干旱，河流水位创历史新低，影响数百万人生计并加速生态临界点逼近。",
        "importance": 5,
        "source_name": "NOAA / Brazil INPE",
    },
    {
        "category": "politics", "title": "Taiwan Strait Tensions — Major Naval Exercises Conducted",
        "title_cn": "台海局势紧张——大规模海军演习",
        "description": "2026年台海周边进行了史上最大规模的联合军事演习，多国海军力量在区域内高度活跃。",
        "importance": 5,
        "source_name": "Multiple Defense Ministries",
    },
    {
        "category": "economy", "title": "De-dollarization Accelerates — BRICS Settlement System Launched",
        "title_cn": "去美元化加速——金砖结算系统启动",
        "description": "金砖国家新开发银行主导的跨境本币结算系统正式运行，覆盖全球35%的贸易结算，挑战美元主导地位。",
        "importance": 4,
        "source_name": "BRICS New Development Bank",
    },
    {
        "category": "military", "title": "New Intermediate-Range Missile Deployment in Asia-Pacific",
        "title_cn": "新型中程导弹部署亚太",
        "description": "多国在亚太地区部署新型中程弹道导弹和高超音速武器系统，改变区域军事平衡。",
        "importance": 4,
        "source_name": "IISS Military Balance",
    },
    {
        "category": "technology", "title": "First Commercial Fusion Reactor Breaks Ground",
        "title_cn": "首个商业核聚变反应堆开工建设",
        "description": "经过多年技术验证，第一个电网级核聚变发电站在美国开工建设，计划2030年代初期并网发电。",
        "importance": 5,
        "source_name": "ITER / Commonwealth Fusion Systems",
    },
]

# Conflict hotspots for world map visualization
# Coordinates are [longitude, latitude] for ECharts scatter on geo map
CONFLICT_HOTSPOTS = [
    {"name": "乌克兰", "lng": 31.0, "lat": 49.0, "intensity": 5, "detail": "俄乌战争持续，2026年春季进入停火谈判关键阶段"},
    {"name": "加沙地带", "lng": 34.5, "lat": 31.5, "intensity": 5, "detail": "以哈冲突持续，区域稳定受严重威胁"},
    {"name": "台海", "lng": 121.0, "lat": 24.0, "intensity": 4, "detail": "大规模海军演习，多国军事力量高度活跃"},
    {"name": "红海/也门", "lng": 43.0, "lat": 15.0, "intensity": 4, "detail": "胡塞武装持续袭击商船，全球航运受扰"},
    {"name": "萨赫勒地带", "lng": -2.0, "lat": 14.0, "intensity": 4, "detail": "马里、布基纳法索、尼日尔政变后伊斯兰极端主义扩散"},
    {"name": "缅甸", "lng": 96.0, "lat": 21.0, "intensity": 4, "detail": "内战持续，军政府与民族武装组织及民主派激烈交火"},
    {"name": "苏丹", "lng": 30.0, "lat": 15.0, "intensity": 4, "detail": "SAF与RSF内战持续，严重人道主义危机"},
    {"name": "刚果(金)", "lng": 23.0, "lat": -2.0, "intensity": 3, "detail": "M23武装组织持续活跃，东部局势动荡"},
    {"name": "朝鲜半岛", "lng": 127.0, "lat": 38.5, "intensity": 3, "detail": "导弹试射频繁，半岛紧张局势维持高位"},
    {"name": "海地", "lng": -72.5, "lat": 19.0, "intensity": 3, "detail": "帮派暴力失控，国家治理基本崩溃"},
    {"name": "埃塞俄比亚", "lng": 39.0, "lat": 9.0, "intensity": 3, "detail": "提格雷冲突后重建困难，多地族群冲突再起"},
    {"name": "阿塞拜疆-亚美尼亚", "lng": 45.0, "lat": 40.0, "intensity": 2, "detail": "纳卡地区争端未完全解决，边境紧张持续"},
]

# Historical data points for ALL indicators (for trend charts & sparklines)
# Format: (indicator_name, [(date_str, value), ...])
# All values are based on real historical data where available, rounded for clarity.
HISTORICAL_DATA = {
    # ===== ECONOMY =====
    "US Fed Funds Rate": [
        ("2000-01-01", 6.50), ("2003-01-01", 1.00), ("2006-01-01", 5.25),
        ("2008-01-01", 0.25), ("2015-01-01", 0.25), ("2018-01-01", 2.50),
        ("2019-01-01", 1.75), ("2020-01-01", 0.25), ("2022-01-01", 4.50),
        ("2023-01-01", 5.50), ("2024-01-01", 5.50), ("2025-01-01", 5.25),
        ("2026-01-01", 5.375),
    ],
    "US CPI YoY": [
        ("2015-01-01", 0.1), ("2017-01-01", 2.1), ("2018-01-01", 2.4),
        ("2019-01-01", 1.8), ("2020-01-01", 1.2), ("2021-01-01", 7.0),
        ("2022-01-01", 6.5), ("2023-01-01", 3.4), ("2024-01-01", 3.3),
        ("2025-01-01", 3.0), ("2026-01-01", 3.1),
    ],
    "US Nonfarm Payrolls": [
        ("2010-01-01", 129.8), ("2013-01-01", 135.5), ("2015-01-01", 142.0),
        ("2018-01-01", 148.5), ("2019-01-01", 151.5), ("2020-01-01", 152.5),
        ("2021-01-01", 145.0), ("2022-01-01", 152.0), ("2023-01-01", 156.0),
        ("2024-01-01", 158.5), ("2025-01-01", 159.2), ("2026-01-01", 159.5),
    ],
    "Global GDP Growth": [
        ("2010-01-01", 5.4), ("2012-01-01", 3.5), ("2015-01-01", 3.4),
        ("2018-01-01", 3.6), ("2019-01-01", 2.8), ("2020-01-01", -3.0),
        ("2021-01-01", 6.3), ("2022-01-01", 3.5), ("2023-01-01", 3.3),
        ("2024-01-01", 3.2), ("2025-01-01", 3.2), ("2026-01-01", 3.1),
    ],
    "WTI Crude Oil": [
        ("2010-01-01", 79.5), ("2012-01-01", 94.0), ("2014-01-01", 93.0),
        ("2015-01-01", 48.7), ("2018-01-01", 65.0), ("2020-01-01", 39.3),
        ("2021-01-01", 68.0), ("2022-01-01", 94.5), ("2023-01-01", 77.6),
        ("2024-01-01", 75.5), ("2025-01-01", 82.0), ("2026-01-01", 78.5),
    ],
    "Gold Price": [
        ("2010-01-01", 1105), ("2012-01-01", 1670), ("2015-01-01", 1160),
        ("2018-01-01", 1290), ("2019-01-01", 1390), ("2020-01-01", 1770),
        ("2021-01-01", 1800), ("2022-01-01", 1800), ("2023-01-01", 1950),
        ("2024-01-01", 2100), ("2025-01-01", 2350), ("2026-01-01", 2420),
    ],
    "S&P 500 Index": [
        ("2010-01-01", 1130), ("2012-01-01", 1300), ("2015-01-01", 2060),
        ("2018-01-01", 2700), ("2019-01-01", 2800), ("2020-01-01", 3230),
        ("2021-01-01", 4300), ("2022-01-01", 4500), ("2023-01-01", 4100),
        ("2024-01-01", 5100), ("2025-01-01", 5700), ("2026-01-01", 5850),
    ],
    "CSI 300 Index": [
        ("2010-01-01", 3100), ("2013-01-01", 2500), ("2015-01-01", 3700),
        ("2018-01-01", 3000), ("2019-01-01", 3500), ("2020-01-01", 5200),
        ("2021-01-01", 4900), ("2022-01-01", 3900), ("2023-01-01", 3400),
        ("2024-01-01", 3700), ("2025-01-01", 3980), ("2026-01-01", 4050),
    ],
    "US 10Y Treasury Yield": [
        ("2010-01-01", 3.85), ("2012-01-01", 1.80), ("2015-01-01", 2.20),
        ("2018-01-01", 2.70), ("2019-01-01", 1.90), ("2020-01-01", 0.90),
        ("2021-01-01", 1.50), ("2022-01-01", 3.90), ("2023-01-01", 3.90),
        ("2024-01-01", 4.20), ("2025-01-01", 4.28), ("2026-01-01", 4.15),
    ],

    # ===== POLITICS =====
    "Active Armed Conflicts": [
        ("2000-01-01", 33), ("2005-01-01", 32), ("2010-01-01", 32),
        ("2015-01-01", 40), ("2018-01-01", 48), ("2019-01-01", 50),
        ("2020-01-01", 52), ("2021-01-01", 54), ("2022-01-01", 55),
        ("2023-01-01", 54), ("2024-01-01", 54), ("2025-01-01", 54),
        ("2026-01-01", 56),
    ],
    "UNSC Resolutions": [
        ("2010-01-01", 58), ("2013-01-01", 47), ("2015-01-01", 63),
        ("2017-01-01", 61), ("2019-01-01", 52), ("2020-01-01", 54),
        ("2021-01-01", 57), ("2022-01-01", 56), ("2023-01-01", 58),
        ("2024-01-01", 58), ("2025-01-01", 58), ("2026-01-01", 62),
    ],
    "Democracy Index Avg": [
        ("2010-01-01", 5.55), ("2013-01-01", 5.53), ("2015-01-01", 5.55),
        ("2017-01-01", 5.50), ("2019-01-01", 5.44), ("2020-01-01", 5.44),
        ("2021-01-01", 5.43), ("2022-01-01", 5.48), ("2023-01-01", 5.50),
        ("2024-01-01", 5.50), ("2025-01-01", 5.50), ("2026-01-01", 5.45),
    ],
    "Trade Restrictions": [
        ("2010-01-01", 1200), ("2013-01-01", 1500), ("2015-01-01", 1800),
        ("2017-01-01", 1900), ("2018-01-01", 2000), ("2019-01-01", 2400),
        ("2020-01-01", 2800), ("2021-01-01", 2900), ("2022-01-01", 3000),
        ("2023-01-01", 3100), ("2024-01-01", 3100), ("2025-01-01", 3100),
        ("2026-01-01", 3400),
    ],

    # ===== MILITARY =====
    "Global Military Expenditure": [
        ("2000-01-01", 0.80), ("2005-01-01", 1.10), ("2010-01-01", 1.55),
        ("2013-01-01", 1.65), ("2015-01-01", 1.70), ("2018-01-01", 1.82),
        ("2019-01-01", 1.90), ("2020-01-01", 2.00), ("2021-01-01", 2.12),
        ("2022-01-01", 2.24), ("2023-01-01", 2.29), ("2024-01-01", 2.32),
        ("2025-01-01", 2.38), ("2026-01-01", 2.44),
    ],
    "Global Nuclear Warheads": [
        ("1986-01-01", 70300), ("1990-01-01", 55000), ("2000-01-01", 35000),
        ("2005-01-01", 27000), ("2010-01-01", 22000), ("2015-01-01", 15850),
        ("2020-01-01", 13400), ("2021-01-01", 13080), ("2022-01-01", 12700),
        ("2023-01-01", 12512), ("2024-01-01", 12512), ("2025-01-01", 12512),
        ("2026-01-01", 12500),
    ],
    "Conflict Fatalities": [
        ("2010-01-01", 35000), ("2012-01-01", 58000), ("2014-01-01", 100000),
        ("2016-01-01", 95000), ("2018-01-01", 78000), ("2019-01-01", 85000),
        ("2020-01-01", 80000), ("2021-01-01", 120000), ("2022-01-01", 220000),
        ("2023-01-01", 170000), ("2024-01-01", 170000), ("2025-01-01", 170000),
        ("2026-01-01", 185000),
    ],

    # ===== TECHNOLOGY =====
    "Global Space Launches": [
        ("2010-01-01", 74), ("2012-01-01", 78), ("2015-01-01", 87),
        ("2017-01-01", 91), ("2018-01-01", 114), ("2019-01-01", 102),
        ("2020-01-01", 114), ("2021-01-01", 146), ("2022-01-01", 186),
        ("2023-01-01", 223), ("2024-01-01", 245), ("2025-01-01", 245),
        ("2026-01-01", 270),
    ],
    "Semiconductor Market": [
        ("2010-01-01", 298), ("2012-01-01", 291), ("2015-01-01", 335),
        ("2017-01-01", 412), ("2018-01-01", 469), ("2019-01-01", 412),
        ("2020-01-01", 440), ("2021-01-01", 556), ("2022-01-01", 574),
        ("2023-01-01", 530), ("2024-01-01", 580), ("2025-01-01", 610),
        ("2026-01-01", 650),
    ],
    "Largest AI Training Compute": [
        ("2012-01-01", 0.001), ("2014-01-01", 0.01), ("2016-01-01", 1),
        ("2017-01-01", 10), ("2018-01-01", 100), ("2019-01-01", 1000),
        ("2020-01-01", 10000), ("2021-01-01", 100000), ("2022-01-01", 2000000),
        ("2023-01-01", 50000000), ("2024-01-01", 100000000), ("2025-01-01", 150000000),
        ("2026-01-01", 250000000),
    ],
    "Renewable Energy Capacity": [
        ("2010-01-01", 1200), ("2012-01-01", 1450), ("2015-01-01", 1900),
        ("2017-01-01", 2200), ("2018-01-01", 2400), ("2019-01-01", 2550),
        ("2020-01-01", 2800), ("2021-01-01", 3100), ("2022-01-01", 3400),
        ("2023-01-01", 3900), ("2024-01-01", 4100), ("2025-01-01", 4300),
        ("2026-01-01", 4500),
    ],

    # ===== LIVELIHOOD =====
    "Atmospheric CO2": [
        ("1960-01-01", 316.9), ("1970-01-01", 325.7), ("1980-01-01", 338.7),
        ("1990-01-01", 354.4), ("2000-01-01", 369.5), ("2005-01-01", 379.8),
        ("2010-01-01", 389.9), ("2015-01-01", 400.8), ("2020-01-01", 414.2),
        ("2022-01-01", 418.5), ("2023-01-01", 421.1), ("2024-01-01", 424.0),
        ("2025-01-01", 425.3), ("2026-01-01", 426.5),
    ],
    "Global Temperature Anomaly": [
        ("1960-01-01", 0.03), ("1970-01-01", 0.05), ("1980-01-01", 0.26),
        ("1990-01-01", 0.45), ("2000-01-01", 0.42), ("2005-01-01", 0.67),
        ("2010-01-01", 0.72), ("2015-01-01", 0.87), ("2020-01-01", 1.01),
        ("2022-01-01", 0.89), ("2023-01-01", 1.20), ("2024-01-01", 1.18),
        ("2025-01-01", 1.25), ("2026-01-01", 1.28),
    ],
    "Extreme Poverty": [
        ("1990-01-01", 1920), ("1995-01-01", 1820), ("2000-01-01", 1680),
        ("2005-01-01", 1400), ("2010-01-01", 1120), ("2015-01-01", 740),
        ("2018-01-01", 680), ("2019-01-01", 650), ("2020-01-01", 710),
        ("2021-01-01", 700), ("2022-01-01", 680), ("2023-01-01", 660),
        ("2024-01-01", 650), ("2025-01-01", 640), ("2026-01-01", 620),
    ],
    "Global Food Price Index": [
        ("2010-01-01", 110), ("2012-01-01", 115), ("2015-01-01", 95),
        ("2017-01-01", 100), ("2018-01-01", 95), ("2019-01-01", 98),
        ("2020-01-01", 102), ("2021-01-01", 125), ("2022-01-01", 140),
        ("2023-01-01", 118), ("2024-01-01", 120), ("2025-01-01", 118),
        ("2026-01-01", 122.5),
    ],
    "Global Refugees": [
        ("2010-01-01", 43.0), ("2012-01-01", 45.0), ("2015-01-01", 65.0),
        ("2017-01-01", 68.0), ("2018-01-01", 70.8), ("2019-01-01", 79.5),
        ("2020-01-01", 82.4), ("2021-01-01", 89.3), ("2022-01-01", 108.4),
        ("2023-01-01", 114.0), ("2024-01-01", 117.0), ("2025-01-01", 114.0),
        ("2026-01-01", 120.0),
    ],
    "Global Population": [
        ("1960-01-01", 3.03), ("1970-01-01", 3.70), ("1980-01-01", 4.45),
        ("1990-01-01", 5.32), ("2000-01-01", 6.14), ("2010-01-01", 6.96),
        ("2020-01-01", 7.82), ("2022-01-01", 8.00), ("2023-01-01", 8.03),
        ("2024-01-01", 8.05), ("2025-01-01", 8.05), ("2026-01-01", 8.12),
    ],

    # ===== COMPOSITE =====
    "Human Development Index": [
        ("2000-01-01", 0.64), ("2005-01-01", 0.67), ("2010-01-01", 0.70),
        ("2015-01-01", 0.72), ("2018-01-01", 0.73), ("2019-01-01", 0.735),
        ("2020-01-01", 0.72), ("2021-01-01", 0.728), ("2022-01-01", 0.732),
        ("2023-01-01", 0.737), ("2024-01-01", 0.737), ("2025-01-01", 0.737),
        ("2026-01-01", 0.739),
    ],
    "Global Peace Index": [
        ("2010-01-01", 2.00), ("2012-01-01", 2.05), ("2015-01-01", 2.10),
        ("2017-01-01", 2.15), ("2018-01-01", 2.18), ("2019-01-01", 2.20),
        ("2020-01-01", 2.22), ("2021-01-01", 2.25), ("2022-01-01", 2.33),
        ("2023-01-01", 2.35), ("2024-01-01", 2.35), ("2025-01-01", 2.35),
        ("2026-01-01", 2.38),
    ],
}


def seed_database(db_session):
    """
    Populate the database with initial indicators, events, and historical data.
    Safe to call multiple times — skips if data already exists.
    """
    from app.models.schema import Indicator, SignalEvent, IndicatorValue

    # Check if already seeded
    existing = db_session.query(Indicator).count()
    if existing > 0:
        return {"status": "skipped", "message": f"Database already has {existing} indicators."}

    # Insert indicators
    indicator_map = {}  # name -> ORM object
    for ind_data in INDICATORS:
        indicator = Indicator(**ind_data)
        db_session.add(indicator)
        db_session.flush()  # get ID
        indicator_map[indicator.name] = indicator

    # Insert historical data
    for indicator_name, data_points in HISTORICAL_DATA.items():
        if indicator_name in indicator_map:
            indicator = indicator_map[indicator_name]
            for date_str, value in data_points:
                iv = IndicatorValue(
                    indicator_id=indicator.id,
                    value=value,
                    recorded_at=datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc),
                )
                db_session.add(iv)

    # Insert signal events
    for evt_data in SIGNAL_EVENTS:
        event = SignalEvent(**evt_data)
        db_session.add(event)

    db_session.commit()

    return {
        "status": "ok",
        "indicators": len(INDICATORS),
        "events": len(SIGNAL_EVENTS),
        "history_points": sum(len(v) for v in HISTORICAL_DATA.values()),
    }
