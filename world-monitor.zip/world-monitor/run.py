#!/usr/bin/env python
"""World Monitor — launch script.

Usage:
    python run.py                # Start on http://localhost:8000
    python run.py --port 8080    # Custom port
    python run.py --reload       # Dev mode with auto-reload
"""

import argparse
import uvicorn


def main():
    parser = argparse.ArgumentParser(description="世界监控室 World Monitor")
    parser.add_argument("--host", default="127.0.0.1", help="Bind address")
    parser.add_argument("--port", type=int, default=8000, help="Bind port")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    args = parser.parse_args()

    print(f"""
    ╔══════════════════════════════════════════╗
    ║     🌍 世界监控室 WORLD MONITOR        ║
    ║                                        ║
    ║  Dashboard: http://{args.host}:{args.port}    ║
    ║  API Docs:  http://{args.host}:{args.port}/docs ║
    ║  Admin:     http://{args.host}:{args.port}/admin║
    ╚══════════════════════════════════════════╝
    """)

    uvicorn.run(
        "app.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )


if __name__ == "__main__":
    main()
