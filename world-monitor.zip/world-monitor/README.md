# 🌍 世界监控室 World Monitor

> 客观、宏观、直观地监测世界现状与变化  
> A global situation awareness dashboard

## Phase 1 MVP — Current Status

**28 indicators** across 6 categories, **8 high-energy signal events**, **52 historical data points** with trend charts.

### Quick Start

```bash
cd world-monitor
pip install -r requirements.txt
python run.py
# Visit http://localhost:8000
```

### Pages

| URL | Description |
|-----|-------------|
| `/` | Main dashboard — cards + charts + signal bar |
| `/category/{slug}` | Category detail (politics/economy/military/technology/livelihood/composite) |
| `/admin/` | Manual data management (add/update indicators & events) |
| `/api/indicators` | JSON API — all indicators |
| `/api/events` | JSON API — signal events |
| `/api/chart-data` | JSON API — historical trend data |
| `/api/summary` | JSON API — dashboard summary |
| `/docs` | Auto-generated Swagger docs |

### Architecture

- **Backend**: FastAPI + SQLAlchemy + SQLite
- **Frontend**: Jinja2 + ECharts + HTMX + Custom CSS (dark theme)
- **Data**: Seed data (static in Phase 1), auto-collection pipeline planned for Phase 2

### Categories

🏛 Politics · 📈 Economy · ⚔ Military · 🔬 Technology · 🌾 Livelihood · 📊 Composite

### Energy Levels

| Level | Label | Meaning |
|-------|-------|---------|
| 5 🔴 | 文明级 | Civilization-changing (nuclear war, AGI, etc.) |
| 4 🟠 | 战略级 | Strategic impact (policy shifts, financial crises) |
| 3 🟡 | 重大级 | Significant (elections, major data surprises) |
| 2 🔵 | 关注级 | Notable (routine policy changes) |
| 1 ⚪ | 背景级 | Background (regular statistics) |

### Tech Stack

- Python 3.12+ · FastAPI · SQLAlchemy · Jinja2 · APScheduler
- ECharts 5 · HTMX · Custom CSS (command-center dark theme)
- Zero Node.js build step — pure Python

### Next Phases

- **Phase 2**: Auto data collection (FRED, World Bank, GDELT, NOAA APIs)
- **Phase 3**: Enhanced visualizations (world map, event timeline, real-time updates)
- **Phase 4**: Full features (export, mobile responsive, more data sources)
