"""Financial market data collector — uses Sina Finance API (accessible from China).

Falls back to yfinance if Sina is unavailable.
"""

import logging

import httpx

from app.collectors.base import BaseCollector
from app.config import COLLECTOR_TIMEOUT

logger = logging.getLogger("world-monitor.collector")

# Sina Finance API endpoint (no key needed, accessible globally)
SINA_API = "https://hq.sinajs.cn/list="

# Sina ticker → DB indicator name
SINA_TICKER_MAP = {
    "gb_inx":   "S&P 500 Index",
    "hf_CL":    "WTI Crude Oil",
    "hf_GC":    "Gold Price",
    "gb_$tnx":  "US 10Y Treasury Yield",
}

# CSI 300 is on Shanghai/Shenzhen exchange, needs different endpoint
CSI300_URL = "https://hq.sinajs.cn/list=sh000300"

# Field indices for Sina US stocks (gb_xxx)
# Format: name,price,change_pct,datetime,change,open,high,low,prev_close,...
GB_FIELDS = {
    "price": 1,
    "change_pct": 2,
}


class YahooFinanceCollector(BaseCollector):
    """Fetches financial market data from Sina Finance API.

    Primary: Sina Finance (free, no key, works in China)
    Fallback: yfinance (if Sina unavailable)
    """

    name = "Financial Markets"

    indicator_map = SINA_TICKER_MAP

    async def fetch(self) -> dict[str, float]:
        """Fetch latest prices from Sina Finance API."""
        results = {}

        async with httpx.AsyncClient(timeout=COLLECTOR_TIMEOUT) as client:
            # Fetch S&P 500 and US 10Y from Sina US stocks
            us_tickers = [k for k in self.indicator_map if k.startswith("gb_")]
            if us_tickers:
                us_results = await self._fetch_sina_us(client, us_tickers)
                results.update(us_results)

            # Fetch commodities from Sina futures
            commodity_tickers = [k for k in self.indicator_map if k.startswith("hf_")]
            if commodity_tickers:
                commodity_results = await self._fetch_sina_futures(client, commodity_tickers)
                results.update(commodity_results)

        # If Sina failed entirely, try yfinance as fallback
        if not results:
            logger.info("Sina Finance returned no data, trying yfinance fallback...")
            results = await self._fetch_yfinance_fallback()

        return results

    async def _fetch_sina_us(self, client, tickers) -> dict[str, float]:
        """Fetch US stock data from Sina."""
        results = {}
        ticker_str = ",".join(tickers)
        url = f"{SINA_API}{ticker_str}"

        try:
            resp = await client.get(url, headers={"Referer": "https://finance.sina.com.cn"})
            resp.raise_for_status()
            # Response is GBK-encoded
            text = resp.content.decode("gbk", errors="ignore")

            for ticker in tickers:
                # Find the var line for this ticker
                prefix = f'var hq_str_{ticker}="'
                start = text.find(prefix)
                if start == -1:
                    continue
                start += len(prefix)
                end = text.find('";', start)
                if end == -1:
                    continue
                data = text[start:end]

                if not data or data.strip() == "":
                    continue

                fields = data.split(",")
                if len(fields) > 2:
                    try:
                        price = float(fields[1])
                        # For gb_$tnx (10Y yield), the price is already in %
                        # it's quoted directly as yield (e.g. 4.15)
                        if ticker == "gb_$tnx":
                            results[ticker] = round(price, 2)
                        else:
                            results[ticker] = round(price, 2)
                        logger.info(f"Sina {ticker}: {results[ticker]}")
                    except (ValueError, IndexError):
                        pass

        except httpx.HTTPError as e:
            logger.warning(f"Sina US stocks HTTP error: {e}")
        except Exception as e:
            logger.warning(f"Sina US stocks unexpected error: {e}")

        return results

    async def _fetch_sina_futures(self, client, tickers) -> dict[str, float]:
        """Fetch commodity futures data from Sina."""
        results = {}
        ticker_str = ",".join(tickers)
        url = f"{SINA_API}{ticker_str}"

        try:
            resp = await client.get(url, headers={"Referer": "https://finance.sina.com.cn"})
            resp.raise_for_status()
            text = resp.content.decode("gbk", errors="ignore")

            for ticker in tickers:
                prefix = f'var hq_str_{ticker}="'
                start = text.find(prefix)
                if start == -1:
                    continue
                start += len(prefix)
                end = text.find('";', start)
                if end == -1:
                    continue
                data = text[start:end]

                if not data or data.strip() == "":
                    continue

                fields = data.split(",")
                # Futures format: price,empty,open,high,low,prev_close,time,...
                if len(fields) > 0:
                    try:
                        price = float(fields[0])
                        results[ticker] = round(price, 2)
                        logger.info(f"Sina {ticker}: {results[ticker]}")
                    except (ValueError, IndexError):
                        pass

        except httpx.HTTPError as e:
            logger.warning(f"Sina futures HTTP error: {e}")
        except Exception as e:
            logger.warning(f"Sina futures unexpected error: {e}")

        return results

    async def _fetch_yfinance_fallback(self) -> dict[str, float]:
        """Fallback: use yfinance if Sina is unavailable."""
        try:
            import yfinance as yf

            tickers = ["^GSPC", "CL=F", "GC=F", "^TNX"]
            name_map = {
                "^GSPC": "S&P 500 Index",
                "CL=F":  "WTI Crude Oil",
                "GC=F":  "Gold Price",
                "^TNX":  "US 10Y Treasury Yield",
            }
            results = {}

            for ticker, name in name_map.items():
                try:
                    t = yf.Ticker(ticker)
                    hist = t.history(period="5d")
                    if not hist.empty:
                        val = float(hist["Close"].iloc[-1])
                        if ticker == "^TNX":
                            val = round(val / 10, 2)
                        results[name] = round(val, 2)
                except Exception as e:
                    logger.debug(f"yfinance {ticker}: {e}")

            return results
        except ImportError:
            logger.debug("yfinance not available")
            return {}
        except Exception as e:
            logger.warning(f"yfinance fallback error: {e}")
            return {}
