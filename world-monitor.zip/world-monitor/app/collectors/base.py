"""Base collector abstract class — defines the interface all data collectors must implement."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class CollectResult:
    """Result of a single indicator update."""
    indicator_name: str
    value: float | None = None
    previous_value: float | None = None
    status: str = "skipped"  # ok / skipped / error
    error: str | None = None


@dataclass
class CollectorReport:
    """Summary report from one collector run."""
    collector_name: str
    results: list[CollectResult] = field(default_factory=list)
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: datetime | None = None
    error: str | None = None

    @property
    def ok_count(self) -> int:
        return sum(1 for r in self.results if r.status == "ok")

    @property
    def skip_count(self) -> int:
        return sum(1 for r in self.results if r.status == "skipped")

    @property
    def error_count(self) -> int:
        return sum(1 for r in self.results if r.status == "error")


class BaseCollector(ABC):
    """Abstract base for all data collectors.

    Subclasses must implement:
      - fetch() → raw data from the external source
      - indicator_map — dict mapping external keys → indicator `name` in DB
    """

    name: str = "base"
    indicator_map: dict[str, str] = {}  # external_key → indicator name in DB

    @abstractmethod
    async def fetch(self) -> dict[str, float]:
        """Fetch raw data from the external source.
        Returns a dict of {external_key: value}.
        """
        ...

    def transform(self, raw: dict[str, float]) -> dict[str, float]:
        """Transform raw data keys → indicator names. Override if needed."""
        return {
            self.indicator_map[k]: v
            for k, v in raw.items()
            if k in self.indicator_map
        }

    async def collect(self, db_session) -> CollectorReport:
        """Full pipeline: fetch → transform → update DB.
        Returns a CollectorReport with per-indicator results.
        """
        from app.collectors.updater import DataUpdater

        report = CollectorReport(collector_name=self.name)
        updater = DataUpdater(db_session)

        try:
            raw = await self.fetch()
        except Exception as e:
            report.error = f"Fetch failed: {e}"
            report.finished_at = datetime.now(timezone.utc)
            return report

        if not raw:
            report.finished_at = datetime.now(timezone.utc)
            return report

        transformed = self.transform(raw)

        for indicator_name, value in transformed.items():
            try:
                result = updater.update_indicator(indicator_name, value)
                report.results.append(result)
            except Exception as e:
                report.results.append(CollectResult(
                    indicator_name=indicator_name,
                    status="error",
                    error=str(e),
                ))

        report.finished_at = datetime.now(timezone.utc)
        return report
