"""World Bank API collector — GDP growth, extreme poverty, global population."""

import logging

import httpx

from app.collectors.base import BaseCollector
from app.config import COLLECTOR_TIMEOUT

logger = logging.getLogger("world-monitor.collector")

# World Bank API base URL
WB_API = "https://api.worldbank.org/v2"


class WorldBankCollector(BaseCollector):
    """Fetches development indicators from the World Bank API.

    Uses the '1W' (World) aggregate country code.
    Free, no API key required.
    """

    name = "World Bank"

    # World Bank indicator code → DB indicator name
    indicator_map = {
        "NY.GDP.MKTP.KD.ZG": "Global GDP Growth",
        "SP.POP.TOTL":       "Global Population",
        "SI.POV.DDAY":       "Extreme Poverty",  # % of population below $2.15/day
    }

    async def fetch(self) -> dict[str, float]:
        """Fetch latest values for each indicator from World Bank API."""
        results = {}

        async with httpx.AsyncClient(timeout=COLLECTOR_TIMEOUT) as client:
            for code in self.indicator_map:
                url = f"{WB_API}/country/1W/indicator/{code}"
                params = {
                    "format": "json",
                    "per_page": 5,
                    "date": "2010:2026",
                }
                try:
                    resp = await client.get(url, params=params)
                    resp.raise_for_status()
                    data = resp.json()

                    # World Bank returns [metadata, data_array]
                    if len(data) < 2 or not data[1]:
                        logger.warning(f"World Bank {code}: no data returned")
                        continue

                    # Find the most recent non-null value
                    latest = None
                    for entry in data[1]:
                        if entry.get("value") is not None:
                            latest = float(entry["value"])
                            logger.info(f"World Bank {code}: {latest} (year {entry.get('date')})")
                            break

                    if latest is not None:
                        results[code] = latest
                    else:
                        logger.warning(f"World Bank {code}: all values null")

                except httpx.HTTPError as e:
                    logger.warning(f"World Bank {code}: HTTP error — {e}")
                except Exception as e:
                    logger.warning(f"World Bank {code}: unexpected error — {e}")

        # Post-processing: convert units to match DB indicators
        processed = {}

        # GDP growth — already in %, use as-is
        if "NY.GDP.MKTP.KD.ZG" in results:
            processed["NY.GDP.MKTP.KD.ZG"] = round(results["NY.GDP.MKTP.KD.ZG"], 2)

        # Population — API returns total count, convert to billions
        if "SP.POP.TOTL" in results:
            pop_billions = round(results["SP.POP.TOTL"] / 1_000_000_000, 3)
            processed["SP.POP.TOTL"] = pop_billions

        # Poverty — API returns % of population, convert to millions of persons
        if "SI.POV.DDAY" in results and "SP.POP.TOTL" in results:
            poverty_rate = results["SI.POV.DDAY"] / 100  # convert % to fraction
            pop_total = results["SP.POP.TOTL"]  # total population
            poverty_absolute = round(poverty_rate * pop_total / 1_000_000, 1)  # millions
            processed["SI.POV.DDAY"] = poverty_absolute
        elif "SI.POV.DDAY" in results:
            # No population data — use poverty rate directly as percentage
            processed["SI.POV.DDAY"] = round(results["SI.POV.DDAY"], 1)

        return processed
