"""Dashboard page routes."""

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from app.models.database import get_db
from app.services.indicator_service import get_dashboard_summary, get_conflict_hotspots
from app.services.big_history_service import (
    get_big_history_page_data,
    KNOWN_ANALOGS,
)
from app.config import CATEGORIES, IMPORTANCE

router = APIRouter()


@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    """Main world monitor dashboard."""
    db = next(get_db())
    try:
        summary = get_dashboard_summary(db)
        # Get big history section data (indicators list + civilization pulse)
        bh_data = get_big_history_page_data(db)
        return request.app.state.templates.TemplateResponse(
            "dashboard.html", {
                "request": request,
                **summary,
                "conflict_hotspots": get_conflict_hotspots(),
                # Big History section data
                "bh_indicators": bh_data["indicators"],
                "bh_known_analogs": bh_data["known_analogs"],
                "bh_civilization_pulse": bh_data["civilization_pulse"],
                "bh_default_indicator_id": bh_data["default_indicator_id"],
                "bh_importance_labels": bh_data["importance_labels"],
            }
        )
    finally:
        db.close()


@router.get("/partials/indicator-cards", response_class=HTMLResponse)
async def indicator_cards_partial(request: Request):
    """Return indicator cards HTML fragment for HTMX auto-refresh."""
    db = next(get_db())
    try:
        summary = get_dashboard_summary(db)
        return request.app.state.templates.TemplateResponse(
            "partials/indicator_cards_group.html",
            {
                "request": request,
                "by_category": summary["by_category"],
                "categories": summary["categories"],
            },
        )
    finally:
        db.close()


@router.get("/category/{category}")
async def category_detail(category: str):
    """Redirect category pages to dashboard anchor."""
    if category not in CATEGORIES:
        return HTMLResponse("Category not found", status_code=404)
    return RedirectResponse(url=f"/#cat-{category}", status_code=302)
