"""Application configuration constants."""

import os

# Project root
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Database
DATABASE_URL = f"sqlite:///{os.path.join(BASE_DIR, 'data', 'world_monitor.db')}"

# Indicator categories
CATEGORIES = {
    "politics":     {"name_cn": "政治", "icon": "🏛", "slug": "politics"},
    "economy":      {"name_cn": "经济", "icon": "📈", "slug": "economy"},
    "military":     {"name_cn": "军事", "icon": "⚔",  "slug": "military"},
    "technology":   {"name_cn": "技术", "icon": "🔬", "slug": "technology"},
    "livelihood":   {"name_cn": "民生", "icon": "🌾", "slug": "livelihood"},
    "composite":    {"name_cn": "综合", "icon": "📊", "slug": "composite"},
}

# Importance levels
IMPORTANCE = {
    5: {"label": "文明级", "color": "importance-5", "css": "#ef4444"},
    4: {"label": "战略级", "color": "importance-4", "css": "#f97316"},
    3: {"label": "重大级", "color": "importance-3", "css": "#eab308"},
    2: {"label": "关注级", "color": "importance-2", "css": "#3b82f6"},
    1: {"label": "背景级", "color": "importance-1", "css": "#6b7280"},
}

# Trend directions
TREND_UP = "up"
TREND_DOWN = "down"
TREND_STABLE = "stable"

# Collector settings
COLLECTOR_TIMEOUT = 15  # HTTP request timeout in seconds
COLLECTOR_ENABLED = True  # Master switch to enable/disable all collectors
